package orderprocessingsystem.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CustomerDetails {
   private int customerId;
   private String customerName;
   private String customerLocation;
   private int orderId;
   private int quantity;
   private double orderAmount;
   private ProductDetails product;
   
}
