package orderprocessingsystem.dao;

import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import orderprocessingsystem.exception.CustomerNotFoundException;
import orderprocessingsystem.exception.ProductNotFoundException;
import orderprocessingsystem.model.CustomerDetails;
import orderprocessingsystem.model.ProductDetails;
import orderprocessingsystem.utility.DBConnectionUtils;

public class CustomerProductDAOImpl implements CustomerProductDAO {
	List<CustomerDetails> customerList = new ArrayList<CustomerDetails>();
	List<ProductDetails>productList=new ArrayList<ProductDetails>();
	@Override
	public CustomerDetails addCustomerDetails(CustomerDetails customer, ProductDetails product) throws CustomerNotFoundException {
		 try {
	         PreparedStatement preparedStatement=DBConnectionUtils.getDBConnection().prepareStatement("insert into OrderTable values(?, ?, ?, ?,?)");
            preparedStatement.setInt(1, customer.getOrderId());
			preparedStatement.setInt(2, customer.getCustomerId());
			preparedStatement.setInt(3, product.getProductId());
			preparedStatement.setInt(4, customer.getQuantity());
			preparedStatement.setDouble(5,customer.getOrderAmount());
		
			int row= preparedStatement.executeUpdate();
			if(row>0) {
				System.out.println("inserted successfully");
				customerList.add(customer);
				productList.add(product);
			
			}
		} catch (SQLException e) {
	      
			throw new CustomerNotFoundException("can't be inserted");
		}
		return customer;
	}
	@Override
	public CustomerDetails addProductDetails(ProductDetails product, CustomerDetails customer) {
	   try {
		PreparedStatement preparedStatement=DBConnectionUtils.getDBConnection().prepareStatement("insert into product values(?,?,?,?)");
	   preparedStatement.setInt(1,product.getOrderId());
	   preparedStatement.setString(2, product.getProductName());
	   preparedStatement.setString(3, product.getDescription());
	   preparedStatement.setString(4, customer.getCustomerName());
	  int row= preparedStatement.executeUpdate();
	   if(row>0) {
		   productList.add(product);
		   customer.setProduct(product);
		   return customer;
	   }
	   } catch (SQLException e) {
		
		e.printStackTrace();
	}
		return null;
	}
	

	@Override
	public CustomerDetails getCustomerDetailsById(Integer cid) throws CustomerNotFoundException {
		CustomerDetails cd=new CustomerDetails();
		ProductDetails pd=new ProductDetails();
		try {
			PreparedStatement prepareStatement=DBConnectionUtils.getDBConnection().prepareStatement("select * from OrderTable where CustomerId=?");
			prepareStatement.setInt(1, cid);
			ResultSet result=prepareStatement.executeQuery();
			while(result.next()) {
				cd.setOrderId(result.getInt(1));
				cd.setCustomerId(result.getInt(2));
				pd.setProductId(result.getInt(3));
				cd.setQuantity(result.getInt(4));
				cd.setOrderAmount(result.getDouble(5));
				return cd;
			}
		} catch (SQLException e) {
			
			throw new CustomerNotFoundException("customer with id "+cid+" is not found");
		}

		return cd;
	}
	@Override
	public ProductDetails updateProductDetails(CustomerDetails customer, ProductDetails product) throws CustomerNotFoundException {
		 try {
			PreparedStatement preparedStatement=DBConnectionUtils.getDBConnection()
					 .prepareStatement("UPDATE product SET productname=?, productdescription=?, customername=? where orderid=? ");
			preparedStatement.setString(1, product.getProductName());
			preparedStatement.setString(2, product.getDescription());
			preparedStatement.setString(3, customer.getCustomerName());
			preparedStatement.setInt(4, product.getOrderId());
			int rows=preparedStatement.executeUpdate();
			if(rows>0) {
				System.out.println("updated successfully for product");
				customer.setProduct(product);
				return product;
			}
			else {
				throw new CustomerNotFoundException("customer with given id is not found");
			}
		} catch (SQLException e) {
		
			e.getMessage();
			}
		 		
		return product;
	}

	@Override
	public CustomerDetails updateCustomerDetails(CustomerDetails customer, ProductDetails product) throws CustomerNotFoundException {
		try {
			PreparedStatement preparedStatement = DBConnectionUtils.getDBConnection()
           	.prepareStatement("UPDATE orderTable SET CustomerId=?,ProductId=?,Quantity=?,OrderAmount=? WHERE OrderId=?;");
			preparedStatement.setInt(1, customer.getCustomerId());
			preparedStatement.setInt(2, product.getProductId());
			preparedStatement.setInt(3, customer.getQuantity());
			preparedStatement.setDouble(4, customer.getOrderAmount());
			preparedStatement.setInt(5, customer.getOrderId());

			int row = preparedStatement.executeUpdate();
			if (row > 0) {
				System.out.println("updated successfully for customer");
				customer.setProduct(product);
				return customer;
			}

		} catch (SQLException e) {
	
		throw new CustomerNotFoundException("customer not found");
		}
		return customer;
	}
	

	@Override
	public String deleteCustomerDetails(Integer Orderid) throws CustomerNotFoundException {
		try {
			PreparedStatement preparedStatement=DBConnectionUtils.getDBConnection().prepareStatement("delete from OrderTable where OrderId=?");
			preparedStatement.setInt(1, Orderid);
			int row=preparedStatement.executeUpdate();
					
			if(row>0) {
				return "customer id with"+Orderid+"is deleted successfully";
			}
			else {
				return "customer with id "+Orderid+" is not found";
			}
		} catch (SQLException e) {
			
			throw new CustomerNotFoundException("customer with id"+Orderid+"is not found");
		}
		
		
	}

	@Override
	public List<CustomerDetails> getAllDetails() {
		
		try {
			Statement statement = DBConnectionUtils.getDBConnection().createStatement();
			ResultSet rs = statement.executeQuery("select * from OrderTable full join product on ordertable.orderid=product.orderid");
			while (rs.next()) {
				CustomerDetails customer=new CustomerDetails();
				ProductDetails product=new ProductDetails();
				
				customer.setOrderId(rs.getInt(1));
				customer.setCustomerId(rs.getInt(2));
				product.setProductId(rs.getInt(3));
				customer.setQuantity(rs.getInt("Quantity"));
				customer.setOrderAmount(rs.getDouble("OrderAmount"));
				product.setOrderId(rs.getInt(6));
				product.setProductName(rs.getString(7));
				product.setDescription(rs.getString(8));
				customer.setCustomerName(rs.getString(9));
				
				customer.setProduct(product);
				customerList.add(customer);
			
				//System.out.println(id);
			}
			/*
			 * String
			 * sql="insert into employee_master values(104,'moeen',45000, '02-05-1985')";
			 * PreparedStatement
			 * preparedStatement=DBConnectionUtils.getDBConnection().prepareStatement(sql);
			 * int rows=preparedStatement.executeUpdate(); if(rows>0) {
			 * System.out.println(rows+"rows inserted"); } else {
			 * System.out.println("something went wrong"); }
			 */
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return customerList;
		
	}
	


}
