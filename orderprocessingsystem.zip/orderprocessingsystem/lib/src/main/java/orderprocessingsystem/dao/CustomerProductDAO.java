package orderprocessingsystem.dao;

import java.util.List;

import orderprocessingsystem.exception.CustomerNotFoundException;
import orderprocessingsystem.exception.ProductNotFoundException;
import orderprocessingsystem.model.CustomerDetails;
import orderprocessingsystem.model.ProductDetails;

public interface CustomerProductDAO {
	 public CustomerDetails addCustomerDetails(CustomerDetails customer, ProductDetails product) throws CustomerNotFoundException;
	  public CustomerDetails addProductDetails(ProductDetails product, CustomerDetails customer);
	   public CustomerDetails getCustomerDetailsById(Integer cid) throws CustomerNotFoundException;
	   public CustomerDetails updateCustomerDetails(CustomerDetails customer, ProductDetails product) throws CustomerNotFoundException;
	   public ProductDetails updateProductDetails(CustomerDetails customer, ProductDetails product) throws CustomerNotFoundException;
	   public String deleteCustomerDetails(Integer cid) throws CustomerNotFoundException;
	   public List<CustomerDetails> getAllDetails();
	 
}
