package orderprocessingsystem.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnectionUtils {
	private static final String URL="jdbc:postgresql://localhost:5432/soleradb";
	//Static method which returns object of Connection type
	public static Connection getDBConnection() {
		
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(URL, "postgres", "Usama2000#");
			//System.out.println("connected with the database");
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return conn;
	}
}
