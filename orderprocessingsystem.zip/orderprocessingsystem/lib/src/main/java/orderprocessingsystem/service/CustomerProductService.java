package orderprocessingsystem.service;


import java.util.List;

import orderprocessingsystem.exception.CustomerNotFoundException;
import orderprocessingsystem.exception.ProductNotFoundException;
import orderprocessingsystem.model.CustomerDetails;
import orderprocessingsystem.model.ProductDetails;

public interface CustomerProductService {
	 public CustomerDetails addCustomerDetails(CustomerDetails customer, ProductDetails product) throws CustomerNotFoundException;
	 public CustomerDetails addProductDetails(CustomerDetails customer, ProductDetails product);
	   public CustomerDetails getCustomerDetailsById(Integer cid) throws CustomerNotFoundException;
	   public CustomerDetails updateCustomerDetails(CustomerDetails customer, ProductDetails product) throws CustomerNotFoundException;
	   public ProductDetails updateProductDetails(CustomerDetails customer, ProductDetails product) throws CustomerNotFoundException;
	   public String deleteCustomerDetails(Integer cid) throws CustomerNotFoundException;
	   public List<CustomerDetails> getAllDetails();
		/*
		 * public ProductDetails addProductDetails(ProductDetails product) throws
		 * ProductNotFoundException; public ProductDetails getProductDetails(Integer
		 * pid) throws ProductNotFoundException; public ProductDetails
		 * updateProductDetails(ProductDetails product) throws ProductNotFoundException;
		 * public ProductDetails deleteProductDetails(Integer pid) throws
		 * ProductNotFoundException;
		 */
}
