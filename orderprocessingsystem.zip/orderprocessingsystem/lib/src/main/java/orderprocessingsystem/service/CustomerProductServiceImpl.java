package orderprocessingsystem.service;

import java.util.List;

import orderprocessingsystem.dao.CustomerProductDAO;
import orderprocessingsystem.dao.CustomerProductDAOImpl;
import orderprocessingsystem.exception.CustomerNotFoundException;
import orderprocessingsystem.exception.ProductNotFoundException;
import orderprocessingsystem.model.CustomerDetails;
import orderprocessingsystem.model.ProductDetails;

public class CustomerProductServiceImpl implements CustomerProductService {

	@Override
	public CustomerDetails addCustomerDetails(CustomerDetails customer, ProductDetails product) throws CustomerNotFoundException {
		CustomerProductDAO customerDao=new CustomerProductDAOImpl();
		return customerDao.addCustomerDetails(customer, product);
	}
	
	

	@Override
	public CustomerDetails getCustomerDetailsById(Integer cid) throws CustomerNotFoundException {
        CustomerProductDAO customerDao=new CustomerProductDAOImpl();
        
		return customerDao.getCustomerDetailsById(cid);
	}

	@Override
	public CustomerDetails updateCustomerDetails(CustomerDetails customer, ProductDetails product) throws CustomerNotFoundException {
		CustomerProductDAO customerDao=new CustomerProductDAOImpl();
		return customerDao.updateCustomerDetails(customer, product);
	}

	@Override
	public String deleteCustomerDetails(Integer cid) throws CustomerNotFoundException {
		CustomerProductDAO customerDao=new CustomerProductDAOImpl();
		return customerDao.deleteCustomerDetails(cid);
		
	}

	@Override
	public List<CustomerDetails> getAllDetails() {
		CustomerProductDAO customerDao=new CustomerProductDAOImpl();
		return customerDao.getAllDetails();
	}

	@Override
	public CustomerDetails addProductDetails(CustomerDetails customer, ProductDetails product) {
		CustomerProductDAO customerDao=new CustomerProductDAOImpl();
		return customerDao.addProductDetails(product, customer);
		
	}



	@Override
	public ProductDetails updateProductDetails(CustomerDetails customer, ProductDetails product)
			throws CustomerNotFoundException {
		CustomerProductDAO customerDao=new CustomerProductDAOImpl();
		return customerDao.updateProductDetails(customer, product);
		
	}
	

	/*
	 * @Override public ProductDetails addProductDetails(ProductDetails product)
	 * throws ProductNotFoundException { // TODO Auto-generated method stub return
	 * null; }
	 * 
	 * @Override public ProductDetails getProductDetails(Integer pid) throws
	 * ProductNotFoundException { // TODO Auto-generated method stub return null; }
	 * 
	 * @Override public ProductDetails updateProductDetails(ProductDetails product)
	 * throws ProductNotFoundException { // TODO Auto-generated method stub return
	 * null; }
	 * 
	 * @Override public ProductDetails deleteProductDetails(Integer pid) throws
	 * ProductNotFoundException { // TODO Auto-generated method stub return null; }
	 */

	

}
