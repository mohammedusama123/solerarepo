package orderprocessingsystem.ui;

import orderprocessingsystem.exception.CustomerNotFoundException;
import orderprocessingsystem.model.CustomerDetails;
import orderprocessingsystem.model.ProductDetails;
import orderprocessingsystem.service.CustomerProductService;
import orderprocessingsystem.service.CustomerProductServiceImpl;

public class OrderProcessingApp {
  public static void main(String[] args) {
	  CustomerProductService customerProductService=new
				  CustomerProductServiceImpl();
		
	/*	  CustomerDetails cd=new CustomerDetails();
		  ProductDetails pd=new ProductDetails();
		  cd.setOrderId(105);
		  cd.setCustomerId(125);
		  pd.setProductId(115);
		  cd.setQuantity(11);
		  cd.setOrderAmount(2000.0);
		  pd.setOrderId(105);
		  pd.setProductName("fan"); 
		  pd.setDescription("remote fan");
		  cd.setCustomerName("samar");
		  try {
			customerProductService.addCustomerDetails(cd, pd);
			customerProductService.addProductDetails(cd, pd);
		} catch (CustomerNotFoundException e1) {
			e1.getMessage();
			}
		*/
		 
		 try {
			System.out.println(customerProductService.deleteCustomerDetails(100));
		} catch (CustomerNotFoundException e) {
			
			e.getMessage();
		}
		 
		 CustomerDetails customer=new CustomerDetails();
		 ProductDetails product=new ProductDetails();
		 customer.setOrderId(105);
		 customer.setCustomerId(1001);
		 product.setProductId(1200);
		 customer.setQuantity(11);
		 customer.setOrderAmount(17000.0);
		 product.setProductName("AC");
		 product.setDescription("4 star air condition");
		 customer.setCustomerName("sameer");
		 product.setOrderId(105);
		 
		 try {
			
			 System.out.println(customerProductService.updateProductDetails(customer, product));
			 System.out.println(customerProductService.updateCustomerDetails(customer, product));
				
		} catch (CustomerNotFoundException e) {
			
			e.getMessage();
		}
		
	
	
	  
	    System.out.println("showing all details");
		/*
		 * System.out.println(customerProductService.getAllDetails()); try {
		 * System.out.println("showing orderDetails for given id");
		 * System.out.println(customerProductService.getCustomerDetailsById(1101)); }
		 * catch (CustomerNotFoundException e1) { e1.getMessage(); } CustomerDetails
		 * cd1=new CustomerDetails(); cd1.setOrderId(103); cd1.setCustomerId(1101);
		 * cd1.setQuantity(15); cd1.setOrderAmount(1200.0); ProductDetails pd1=new
		 * ProductDetails(); pd1.setProductId(1011); pd1.setProductName("calculator");
		 * pd1.setDescription("used for  modern scientific calculations"); try {
		 * System.out.println(customerProductService.updateCustomerDetails(cd1, pd1)); }
		 * catch (CustomerNotFoundException e2) { e2.getMessage(); }
		 * 
		 * 
		 * try { System.out.println(customerProductService.deleteCustomerDetails(100));
		 * } catch (CustomerNotFoundException e) { e.getMessage(); }
		 * System.out.println("showing updated details");
		 */
	      System.out.println(customerProductService.getAllDetails());
	}
     
  }



